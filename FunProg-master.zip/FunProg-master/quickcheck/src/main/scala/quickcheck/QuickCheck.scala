package quickcheck

import common._

import org.scalacheck._
import Arbitrary._
import Gen._
import Prop._

abstract class QuickCheckHeap extends Properties("Heap") with IntHeap {

  lazy val genHeap: Gen[H] = for {
    v <- arbitrary[A]
    h <- oneOf(const(empty), genHeap)
  } yield insert(v, h)

  implicit lazy val arbHeap: Arbitrary[H] = Arbitrary(genHeap)

  def heapSort(h: H): List[A] = {
    if (isEmpty(h)) Nil
    else findMin(h) :: heapSort(deleteMin(h))
  }

  // 2 el into empty -> min of h is smallest of 2
  property("2 into Empty => min == smallest of 2") = forAll { (a: Int, b: Int) =>
    (a != b) ==> {
      findMin(insert(a, insert(b, empty))) == ord.min(a, b)
    }
  }

  property("associative meld") = forAll { (h: H, i: H, j: H) =>
    val a = meld(meld(h, i), j)
    val b = meld(h, meld(i, j))
    heapSort(a) == heapSort(b)
  }

  // 1 el into empty -> rm min == empty
  property("1 el into empty -> rm min == empty") = forAll { a: Int =>
    isEmpty(deleteMin(insert(a, empty)))
  }

  // any heap -> rm min into list -> end is sorted
  property("any heap -> rm min into list -> end is sorted") = {

    forAll { h: H =>
      val l = heapSort(h)
      l == l.sorted(ord)
    }
  }

  // min of any melding -> min of 1 or min of 2
  property("min of any melding -> min of 1 or min of 2") = forAll { (h1: H, h2: H) =>
    (!isEmpty(h1) && !isEmpty(h2) && h1 != h2) ==> {
      val melded = findMin(meld(h1, h2))
      melded == findMin(h1) || melded == findMin(h2)
    }
  }
}
